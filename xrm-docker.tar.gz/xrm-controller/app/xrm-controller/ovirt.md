# xrm-controller OVirt API

Generate config `/ovirt/generate/:name`
    - site_primary_url
	- site_primary_username
	- site_primary_password
	- site_secondary_url
	- site_secondary_username
	- site_secondary_password
	- storage_domains

Delete config `/ovirt/delete/:name`

Failover (for generated config) `/ovirt/failover/:name`
